import React ,{ useEffect,useState }from 'react'

function Counter() {
  
  // eslint-disable-next-line no-undef
  const [count,setCount] = useState(0);


  // eslint-disable-next-line no-undef
  useEffect(()=>{
    console.log("Count changed:",count);
  },[count]);//depends on count


  return(
    <div>
        <h2>Count: {count}</h2>
        <button onClick={()=>setCount(count+1)}>increases</button>
    </div>
  )
}

export default Counter
