import React ,{ Useeffect }from 'react'


function useeffect(){
    Useeffect(()=>{
        console.log("Componenet rendered or updated!");
    });

    return <h2>Hello React useeffect!</h2>
}

export default useeffect;