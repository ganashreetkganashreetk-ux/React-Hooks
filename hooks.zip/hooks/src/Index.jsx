import React from 'react'
import { BrowserRouter,Link } from 'react-router-dom'

function Index() {
  return (
    <div><h1>This is index Page</h1>
        <nav>
            <Link to='/Home'>Homepage</Link>
            <Link to='/About'>Homepage</Link>
            <Link to='/Contact'>Homepage</Link>
            <Link to='/Error'>Error</Link>
            
        </nav>
    </div>
  )
}

export default Index