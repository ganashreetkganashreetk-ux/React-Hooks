import "./ExternalCss.css";



function External() {
  return <h1 className="title"><img src="moon.png" alt="moon.png" width="20%"height="15%"/>React External CSS</h1>
  
    
  
}

export default External