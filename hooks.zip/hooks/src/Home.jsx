
import React from 'react'
import { useNavigate } from 'react-router-dom'

function Home() {
    const navigate = useNavigate();
    function handelLogin(){
        console.log("Button clicked");
        navigate('/contact')
    }
    
    
  return (
    <div>Home:
    <button onClick={handelLogin}>Login</button>
        
        

    </div>
    
  )
}

export default Home