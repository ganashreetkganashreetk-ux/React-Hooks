import React from 'react'


  function Temperature({ value}){
    return(
        <p style={{ color:value>30?"red":"blue"}}>Temperature:{value}</p>
    );
}


export default Temperature