/* eslint-disable no-undef */
import React,{ useEffect,useState } from 'react';

function UsersList() {
    const [,SetUsers]=useState([]);
    const [loading, SetLoading] = useState(true);

    useEffect(()=>{
        async function fetchData(){
            const res=await fetch("https://jsonplaceholder.typicode.com/users");
            const data = await res.json();
            SetUsers(data);
            SetLoading(true);
        }
        fetchData();
    },[]); //fetch ones
  return(
    <div>
        <h2>Users List</h2>
        {loading ?(
            <p>Loading....</p>
        ):(
            <ul>
                // eslint-disable-next-line no-undef
                {users.map((user)=>(
                    <>
                    <li key={user.id}>{user.name}</li>
                    <p key={user.id}>{user.category}</p>
                    </>
                ))}
            </ul>
        )}
    </div>
  );
}

export default UsersList